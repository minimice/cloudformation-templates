# Listener Rule Priority Lambda

[![pipeline status](https://gitlab.scania.com/ecis/ecis-lambda-listener-rule-priority/badges/master/pipeline.svg)](https://gitlab.scania.com/ecis/ecis-lambda-listener-rule-priority/commits/master)

Lambda function which returns an available listener rule priority to be used when provided with a load balancer listener.

## Contact info
**Responsible Team:** ECIS  
**Product Owner:** Kristoffer Wänglund <ssskwk@scania.com>  
**Teams:** [Microsoft Teams](https://teams.microsoft.com/l/channel/19%3a0d65132f0e51436da41578226eefcd76%40thread.skype/Group%2520ECIS?groupId=9bd9d101-da85-4faf-9620-6356d521dcd6&tenantId=3bc062e4-ac9d-4c17-b4dd-3aad637ff1ac)  

## References
**Prod:** TBD  
**Test:** TBD  
**Dev:** TBD  
**Repository:** [Gitlab](https://gitlab.scania.com/ecis/ecis-lambda-listener-rule-priority)  
**Build server:** [Gitlab CI](https://gitlab.scania.com/ecis/ecis-lambda-listener-rule-priority/pipelines)  

## Downstream dependencies
* [planner](https://gitlab.scania.com/ecis/planner)  

## Upstream dependencies
* None  

## Development

### Prerequisites 
* [Python3.7](https://www.python.org/downloads/release/python-370)  

