#!/bin/bash

SOURCE_DATE=$1
DEST_FROM_DATE=$2
DEST_TO_DATE=$3
PLAS_API=${4%/}/v1.0

if [ $# -ne 4 ]; then
	echo >&2 "Usage: $0 <source date> <destination from date> <destination to date> <planner uri>"
	echo >&2 "Example:"
	echo >&2 "$0 20171102 20171106 20171110 https://ice-lots.eci.zone/planner"
	exit 2
fi

DATEFILES="sourceList destinationList vehicleList materialTypeList locationList"

# Extract proxy username and password from $http_proxy
if [ ! "$http_proxy"=="" ]; then
	U=$(echo $http_proxy | sed 's|http://\([^:]*\).*|\1|')
	P=$(echo $http_proxy | sed 's|http://[^:]*:\([^@]*\).*|\1|')
	PROXY_OPTS="-Dhttps.proxyHost=proxyseso.scania.com -Dhttps.proxyPort=8080 -Dhttps.proxyUser=$U -Dhttps.proxyPassword=$P"
fi


# Find out if we have the files cached already
CACHED=1
for NAME in $DATEFILES; do
	FILE="${SOURCE_DATE}_${DEST_FROM_DATE}_${DEST_TO_DATE}_${NAME}.json"

	if [ ! -f "$FILE" ]; then
		CACHED=0
	fi
done

if [ $CACHED -eq 0 ]; then
	# Sources, Destinations and Vehicles
	echo Running LOTSDataHandling
	java -jar $PROXY_OPTS target/LOTSDataHandling-jar-with-dependencies.jar $SOURCE_DATE $DEST_FROM_DATE $DEST_TO_DATE

	# Locations
	echo Running LOTSDataHandlingLocations
	java -jar $PROXY_OPTS target/LOTSDataHandlingLocations-jar-with-dependencies.jar $SOURCE_DATE $DEST_FROM_DATE $DEST_TO_DATE
	echo "Converting locationList.json from ISO-8859-1 to UTF-8"

	#$FILE is locationList with date, as it is the last element in $DATEFILES (refer to loop above)
	iconv -f ISO-8859-1 -t UTF-8 locationList.json > $FILE  
	rm locationList.json
else
	echo Cache for given date range exist. Please remove at least one file to invalid the cache
	echo and then run again. For instance:
	echo rm $FILE
fi

# Upload to planner
echo "Setting planner to manual"
curl -XPUT "$PLAS_API/put/mode/manual"

for NAME in $DATEFILES; do
	FILE="${SOURCE_DATE}_${DEST_FROM_DATE}_${DEST_TO_DATE}_${NAME}.json"

	if [ ! -f "$FILE" ]; then
		echo "File does not exist: '$FILE'" >&2
		exit 2
	fi

	echo "Uploading $NAME"
	curl -XPUT -H'Content-type: Application/json' -d"@$FILE" "$PLAS_API/put/$NAME"
done

echo
echo Worldstate should now be updated. In order to start planning, run:
echo curl -XPATCH $PLAS_API/patch/plan/start

