package com.scania.lotsdatahandling.domain;

import com.scania.lotsdatahandling.proto.LoadTypeMiningOuterClass;
import com.scania.lotsdatahandling.geo.GeographicPose;

public class Storage {
    private final StorageType storageType;
    @JsonRequired
    private final Long id;
    @JsonRequired
    private final LoadTypeMiningOuterClass.LoadTypeMining materialType;
    @JsonRequired
    private GeographicPose location;
    @JsonRequired
    private GeographicPose exitPosition;
    @JsonRequired
    private Double flow;

    private Long materialId;
    private Long priority;
    private Long loadTime;
    private Long unloadTime;
    private Long designatedDestinationLocationId;
    private Long locationId;

    public Storage(StorageType storageType, Long id, LoadTypeMiningOuterClass.LoadTypeMining materialType) {
        this.storageType = storageType;
        this.id = id;
        this.materialType = materialType;
    }

    public Storage(StorageType storageType, Long id, LoadTypeMiningOuterClass.LoadTypeMining materialType, GeographicPose location, GeographicPose exitPosition, Double flow) {
        this.storageType = storageType;
        this.id = id;
        this.materialType = materialType;
        this.location = location;
        this.exitPosition = exitPosition;
        this.flow = flow;
    }

    public Storage(StorageType storageType, Long id, LoadTypeMiningOuterClass.LoadTypeMining materialType, GeographicPose location, GeographicPose exitPosition, Double flow, Long materialId, Long priority, Long loadTime, Long designatedDestinationLocationId,Long locationId) {
        this.storageType = storageType;
        this.id = id;
        this.materialType = materialType;
        this.location = location;
        this.exitPosition = exitPosition;
        this.flow = flow;

        this.materialId = materialId;
        this.priority = priority;
        this.loadTime = loadTime;
        this.designatedDestinationLocationId = designatedDestinationLocationId;
        this.locationId = locationId;
    }

    public Storage(StorageType storageType, Long id, LoadTypeMiningOuterClass.LoadTypeMining materialType, GeographicPose location, GeographicPose exitPosition, Double flow, Long materialId, Long priority, Long unloadTime,Long locationId) {
        this.storageType = storageType;
        this.id = id;
        this.materialType = materialType;
        this.location = location;
        this.exitPosition = exitPosition;
        this.flow = flow;

        this.materialId = materialId;
        this.priority = priority;
        this.unloadTime = unloadTime;
        this.locationId = locationId;
    }

    public void setExitPosition(GeographicPose exitPosition) {
        this.exitPosition = exitPosition;
    }

    public void setFlow(Double flow) {
        this.flow = flow;
    }

    public void setLocation(GeographicPose location) {
        this.location = location;
    }

    public GeographicPose getExitPosition() {
        return exitPosition;
    }

    public Double getFlow() {
        return flow;
    }

    public Long getId() {
        return id;
    }

    public GeographicPose getLocation() {
        return location;
    }

    public LoadTypeMiningOuterClass.LoadTypeMining getMaterialType() {
        return materialType;
    }

    public StorageType getStorageType() {
        return storageType;
    }

    public Long getMaterialId() {
        if (null == materialId) {
            return 0L;
        }
        return materialId;
    }

    public Long getPriority() {
        if (null == priority) {
            return 0L;
        }
        return priority;
    }

    public Long getLoadTime() {
        if (null == loadTime) {
            return 0L;
        }
        return loadTime;
    }

    public Long getUnloadTime() {
        if (null == unloadTime) {
            return 0L;
        }
        return unloadTime;
    }

    public Long getDesignatedDestinationLocationId() {
        if (null == designatedDestinationLocationId) {
            return 0L;
        }
        return designatedDestinationLocationId;
    }

    public Long getLocationId() {
        if (null == locationId) {
            return 0L;
        }
        return locationId;
    }

    public void setDesignatedDestinationLocationId(Long designatedDestinationLocationId) {
        this.designatedDestinationLocationId = designatedDestinationLocationId;
    }

    public void setLoadTime(Long loadTime) {
        this.loadTime = loadTime;
    }

    public void setLocationId(Long locationId) {
        this.locationId = locationId;
    }

    public void setMaterialId(Long materialId) {
        this.materialId = materialId;
    }

    public void setPriority(Long priority) {
        this.priority = priority;
    }

    public void setUnloadTime(Long unloadTime) {
        this.unloadTime = unloadTime;
    }
    
}
