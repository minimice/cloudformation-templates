package com.scania.lotsdatahandling.dataBasedPlannerHelpClasses;

import com.scania.lotsdatahandling.proto.LoadTypeMiningOuterClass;
import com.scania.lotsdatahandling.geo.GeographicPose;
import com.scania.lotsdatahandling.domain.Storage;
import com.scania.lotsdatahandling.domain.StorageType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The DestinationListForPlanner-object has a field containing a list of destinations, that is
 * List<DestinationOuterClass.Destination> destinationList.
 * This list is what is used to set up a planning-problem for the planner to solve.
 *
 * @author MANRRZ
 */
public class DestinationListForPlanner {

    private List<Storage> destinationListAPI;


    
        /**
     * Gets the field destinationList which contains Destination-objects.
     *
     * @return List<DestinationOuterClass.Destination>
     */
    public List<Storage> getDestinationListAPI() {
        return this.destinationListAPI;
    }

    /**
     * Sets the field destinationList according to the HashMap destinationMap.
     *
     * @param destinationMap
     */
    public void setDestinationListAPI(Map<Integer,DestinationMapForPlanner.LocationData> destinationMap) {
        this.destinationListAPI = calculateAndGetDestinationListForPlannerAPI(destinationMap);
    }
    

    private List<Storage> calculateAndGetDestinationListForPlannerAPI(Map<Integer, DestinationMapForPlanner.LocationData> destinationMap) {
        List<Storage> destinationList = new ArrayList<>();
        for (int destinationMapKey : destinationMap.keySet()){// for every location (destination)
            DestinationMapForPlanner.LocationData locationData = destinationMap.get(destinationMapKey);
            Map<Integer, DestinationMapForPlanner.MaterialAtDestination> materialAtLocation = locationData.materialAtLocation;
            for (int materialAtLocationKey : materialAtLocation.keySet()){// for every material type
                DestinationMapForPlanner.MaterialAtDestination materialAtDestination = materialAtLocation.get(materialAtLocationKey);
                long id = materialAtDestination.destinationID;
                double altitude = 0D;
                double longitude = locationData.longitude;
                double latitude = locationData.latitude;
                if (0.0d == longitude && 0.0d == latitude) {
                    System.out.println("Destination " + Long.toString(id) + " is excluded, since it has invalid coordinates (both longitude and latitude are 0.0)!");
                } else {
                    double outFlow = materialAtDestination.weight;
                    LoadTypeMiningOuterClass.LoadTypeMining typeOfMaterial = LoadTypeMiningOuterClass.LoadTypeMining.LOAD_TYPE_OTHER;
                    long locationId = destinationMapKey;
                    long unloadTime = 20 * 60 * 1000; // 20 minutes in milliseconds
                    long priority = 0L;
                    long materialId = materialAtLocationKey;
                    GeographicPose pose = new GeographicPose(longitude, latitude, altitude);
                    Storage storage = new Storage(StorageType.DESTINATION, id, typeOfMaterial, pose, pose, outFlow, materialId, priority, unloadTime, locationId);
                    destinationList.add(storage);
                }
            }
        }
        return destinationList;
    }
}
