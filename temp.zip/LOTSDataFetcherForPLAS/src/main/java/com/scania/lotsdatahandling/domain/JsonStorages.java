package com.scania.lotsdatahandling.domain;

import com.scania.lotsdatahandling.domain.Storage;
import java.util.List;


public class JsonStorages {
    @JsonRequired
    private List<Storage> storages;

    public List<Storage> getStorages() {
        return storages;
    }

    public void setStorages(List<Storage> storages) {
        this.storages = storages;
    }
    
}
