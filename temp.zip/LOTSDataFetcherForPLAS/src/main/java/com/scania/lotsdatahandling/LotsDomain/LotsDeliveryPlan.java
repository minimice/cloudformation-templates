package com.scania.lotsdatahandling.LotsDomain;

import java.util.Date;

public class LotsDeliveryPlan {

    public String DeliveryDate;

    public String ReceiverNumber;

    public String ReceiverName;

    public String ProductNumber;

    public String ProductName;

    public Double Volume;

    public String CustomerNumber;
}
