package com.scania.lotsdatahandling.domain;

import com.google.gson.Gson;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Collection;
import java.util.logging.Level;

public class AnnotatedDeserializer<T> implements JsonDeserializer<T> {

    public T deserialize(JsonElement je, Type type, JsonDeserializationContext jdc) throws JsonParseException {
        T pojo = new Gson().fromJson(je, type);

        try {
            tryParse(pojo);
        } catch (IllegalArgumentException ex) {
            ex.printStackTrace();
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        }
        return pojo;

    }

    private void tryParse(Object obj) throws IllegalArgumentException, IllegalAccessException {
        Field[] fields = obj.getClass().getDeclaredFields();
        for (Field f : fields) {
            if (f.getAnnotation(JsonRequired.class) != null) {
                f.setAccessible(true);
                if (f.get(obj) == null) {
                    throw new JsonParseException("Missing field in JSON: " + f.getName());
                }
                if (!f.getType().isPrimitive()) {
                    if (f.get(obj) instanceof Collection) {
                        Collection<?> arrayListField = (Collection<?>) f.get(obj);
                        for (Object object : arrayListField) {
                            tryParse(object);
                        }
                    } else {
                        tryParse(f.get(obj));
                    }

                }
            }

        }
    }
}
