package com.scania.lotsdatahandling.domain;



public enum StorageType {
    SOURCE, DESTINATION, BUSSTOP
}
