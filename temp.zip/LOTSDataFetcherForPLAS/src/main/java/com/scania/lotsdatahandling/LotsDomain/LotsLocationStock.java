package com.scania.lotsdatahandling.LotsDomain;

import java.util.Date;


public class LotsLocationStock {
    public String LocationNumber;
    public String LocationName;
    public Double LocationLat;
    public Double LocationLong;
    public String ProductNumber;
    public String ProductName;
    public Double Stocklevel;
    public String ReceiverNumber;
    public String Snapshotdate;
    
}
