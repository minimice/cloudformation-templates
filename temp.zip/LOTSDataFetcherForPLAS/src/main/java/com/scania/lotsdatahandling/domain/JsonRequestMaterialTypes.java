package com.scania.lotsdatahandling.domain;

import java.util.List;

public class JsonRequestMaterialTypes {

    @JsonRequired
    private List<Material> materialTypes;

    public List<Material> getMaterialTypes() {
        return materialTypes;
    }

    public void setMaterialTypes(List<Material> materialTypes) {
        this.materialTypes = materialTypes;
    }
}
