package com.scania.lotsdatahandling.LotsDomain;


public class LotsReceiver {
    public String ReceiverNumber;
    public String ReceiverName;
    public Double ReceiverLat;
    public Double ReceiverLong;
}
