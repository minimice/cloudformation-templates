package com.scania.lotsdatahandling.domain;



public enum LoadType {
    ROCKSLOAD, SALTLOAD, PEOPLELOAD, OTHERLOAD, UNDEFINED
}
