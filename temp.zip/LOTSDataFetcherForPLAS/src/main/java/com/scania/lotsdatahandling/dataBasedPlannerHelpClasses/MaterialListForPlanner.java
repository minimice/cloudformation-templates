package com.scania.lotsdatahandling.dataBasedPlannerHelpClasses;

import com.scania.lotsdatahandling.domain.LoadType;
import com.scania.lotsdatahandling.domain.Material;
import com.scania.lotsdatahandling.domain.Vehicle;
import com.scania.lotsdatahandling.domain.VehicleLoad;

import java.util.ArrayList;
import java.util.List;

public class MaterialListForPlanner {

    private List<Material> materialTypeList;

    public MaterialListForPlanner(DataListsForPlanner dataListsForPlanner) {
        this.materialTypeList = new ArrayList<>();

        for (DataListsForPlanner.MaterialInfo materialEntry : dataListsForPlanner.getMaterialInfoList()) {
            Material newMaterial = new Material(Long.parseLong(materialEntry.materialId),materialEntry.materialName);
            this.materialTypeList.add(newMaterial);
        }
    }

    public List<Material> getMaterialTypeList() {
        return this.materialTypeList;
    }
}
