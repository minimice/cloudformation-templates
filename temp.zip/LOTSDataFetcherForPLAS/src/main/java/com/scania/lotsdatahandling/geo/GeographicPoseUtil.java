package com.scania.lotsdatahandling.geo;


public class GeographicPoseUtil {

    public GeographicPoseUtil() {

    }

    static public double estimateDistanceBtw_F64(GeographicPose from, GeographicPose to) {

        double dLat = Math.toRadians(to.getLatitude() - from.getLatitude());
        double dLon = Math.toRadians(to.getLongitude() - from.getLongitude());
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(from.getLatitude()))
                * Math.cos(Math.toRadians(to.getLatitude())) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double d = 6371 * c;
        /* Distance in km, 6371 = radius of earth in km*/

        d = d * 1000;
        /*convert to m*/

        return d;
    }



}
