package com.scania.lotsdatahandling.domain;


public class Location {

    private String name;
    private Long id;
    private GeographicPose point;

    public Location() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPoint(GeographicPose point) {
        this.point = point;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public GeographicPose getPoint() {
        return point;
    }

}
