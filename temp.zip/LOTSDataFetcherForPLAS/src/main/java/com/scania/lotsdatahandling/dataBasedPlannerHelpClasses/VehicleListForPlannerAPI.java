package com.scania.lotsdatahandling.dataBasedPlannerHelpClasses;

import com.scania.lotsdatahandling.domain.LoadType;
import com.scania.lotsdatahandling.domain.Vehicle;
import com.scania.lotsdatahandling.domain.VehicleLoad;

import java.util.ArrayList;
import java.util.List;

public class VehicleListForPlannerAPI {

    private List<Vehicle> vehicleList;

    public VehicleListForPlannerAPI(DataListsForPlanner dataListsForPlanner) {
        this.vehicleList = new ArrayList<>();

        for (DataListsForPlanner.VehicleInfo vehicleEntry : dataListsForPlanner.getVehicleInfoList()) {
            this.vehicleList.add(vehicleHelper(Long.parseLong(vehicleEntry.vehicleId), 1, Double.parseDouble(vehicleEntry.capacity)));
        }
    }

    public List<Vehicle> getVehicleList() {
        return this.vehicleList;
    }

    private Vehicle vehicleHelper(long id, double speed, double maxAmount) {

        VehicleLoad vehicleLoad = new VehicleLoad(LoadType.OTHERLOAD, maxAmount);
        List<VehicleLoad> vehicleLoads = new ArrayList<>();
        vehicleLoads.add(vehicleLoad);
        Vehicle vehicle = new Vehicle(id, vehicleLoads);
        
        vehicle.setSpeed(speed);

        return vehicle;
    }
}
