package com.scania.lotsdatahandling.LotsDomain;

public class LotsLocation {

    public String LocationNumber;

    public String LocationName;

    public Double LocationLat;

    public Double LocationLong;
}
