package com.scania.lotsdatahandling.dataBasedPlannerHelpClasses;

import java.util.HashMap;
import java.util.Map;

/**
 * The DestinationMapForPlanner-object has a field containing a HashMap with (maybe) modified information from
 * the DataListsForPlanner dataListsForPlanner, that is
 * Map<Integer,LocationData> destinationMap.
 * The key is the location ID of the destination, and the value is the corresponding location data.
 * <p>
 * The information is modified if equivalent multiples of destinations are present in dataListsForPlanner.
 *
 * @author MANRRZ
 */
public class DestinationMapForPlanner {

    private Map<Integer,LocationData> destinationMap;

    public DestinationMapForPlanner(){
        this.destinationMap = new HashMap<>();
    }

    /**
     * Gets the field destinationMap, that is
     * Map<Integer,LocationData> destinationMap.
     * The key is the location ID of the destination, and the value is the corresponding location data.
     *
     * @return Map<Integer,LocationData> destinationMap
     */
    public Map<Integer,LocationData> getDestinationMap() {
        return this.destinationMap;
    }

    /**
     * Sets the field destinationMap according to the DataListsForPlanner dataListsForPlanner.
     *
     * @param dataListsForPlanner
     */
    public void setDestinationMap(DataListsForPlanner dataListsForPlanner) {
        this.destinationMap = calculateAndGetDestinationMap(dataListsForPlanner);
    }

    /**
     * Reads the information of the DataListsForPlanner dataListsForPlanner and (maybe) modifies it and creates the
     * HashMap destinationMap.
     *
     * @param dataListsForPlanner
     * @return Map<Integer, LocationData>
     */
    private Map<Integer,LocationData> calculateAndGetDestinationMap(DataListsForPlanner dataListsForPlanner){
        Map<Integer, LocationData> destinationMap = new HashMap<>();

        for (DataListsForPlanner.DestinationInfoData destinationEntry : dataListsForPlanner.getDestinationInfoDataList()) {
            LocationData locationData = new LocationData();
            locationData.latitude = Double.parseDouble(destinationEntry.latitude);
            locationData.longitude = Double.parseDouble(destinationEntry.longitude);
            int locationID = Integer.parseInt(destinationEntry.locationID);
            destinationMap.put(locationID, locationData);
        }

        int destinationID = 0;
        HashMap<Integer, LocationData> locationsWithNoPosition = new HashMap<>();
        for (DataListsForPlanner.DestinationDemandData destinationEntry : dataListsForPlanner.getDestinationDemandDataList()) {
            LocationData locationData = new LocationData();
            int locationID = Integer.parseInt(destinationEntry.locationID);
            int materialID = Integer.parseInt(destinationEntry.materialID);
            double weight = 1 * Double.parseDouble(destinationEntry.volume);  // transformation coefficient m3 -> ton is set to 1
            // Check if this is the first encounter with destination denoted by locationID
            if (destinationMap.containsKey(locationID)) {
                locationData = destinationMap.get(locationID);
                if (locationData.materialAtLocation != null) {
                    // Check if this is the first encounter with destination denoted by locationID and material type denoted by materialID
                    if (locationData.materialAtLocation.containsKey(materialID)) {
                        MaterialAtDestination materialAtDestination = locationData.materialAtLocation.get(materialID);
                        materialAtDestination.weight += weight;
                        locationData.materialAtLocation.put(materialID,materialAtDestination);
                    } else {
                        MaterialAtDestination materialAtDestination = new MaterialAtDestination();
                        materialAtDestination.weight = weight;
                        materialAtDestination.destinationID = destinationID;
                        locationData.materialAtLocation.put(materialID, materialAtDestination);
                        destinationID++;
                    }
                } else {
                    MaterialAtDestination materialAtDestination = new MaterialAtDestination();
                    materialAtDestination.weight = weight;
                    materialAtDestination.destinationID = destinationID;
                    Map<Integer, MaterialAtDestination> materialAtLocation = new HashMap<>();
                    materialAtLocation.put(materialID, materialAtDestination);
                    locationData.materialAtLocation = materialAtLocation;
                    destinationID++;

                }
            } else if (!locationsWithNoPosition.containsKey(locationID)) {

                MaterialAtDestination materialAtDestinationWithNoPosition = new MaterialAtDestination();
                materialAtDestinationWithNoPosition.weight = weight;
                locationData.materialAtLocation.put(materialID, materialAtDestinationWithNoPosition);
                locationsWithNoPosition.put(locationID,locationData);

            } else if (!locationsWithNoPosition.get(locationID).materialAtLocation.containsKey(materialID)) {

                MaterialAtDestination materialAtDestinationWithNoPosition = new MaterialAtDestination();
                materialAtDestinationWithNoPosition.weight = weight;
                locationData = locationsWithNoPosition.get(locationID);
                locationData.materialAtLocation.put(materialID, materialAtDestinationWithNoPosition);
            }
        }
        for (Map.Entry locationsWithNoPositionEntry : locationsWithNoPosition.entrySet() ) {

//            m_log.info("No position available -> Destination (location ID) " + locationsWithNoPositionEntry.getKey() + "(this destination is discarded in the planning)");
            LocationData locationWithNoPosition = (LocationData) locationsWithNoPositionEntry.getValue();
            for (Map.Entry locationsWithNoPositionMaterialEntry : locationWithNoPosition.materialAtLocation.entrySet()) {
//                m_log.info("Material: " + locationsWithNoPositionMaterialEntry.getKey() + ", demand: " + ((MaterialAtDestination) locationsWithNoPositionMaterialEntry.getValue()).weight + " (ton)");
            }
        }

        return destinationMap;
    }

    /**
     * The LocationData-object contains fields corresponding to information about the location (destination)
     * in question.
     * <p>
     * The field Map<Integer,MaterialAtDestination> materialAtLocation has as key the material ID and as value
     * MaterialAtDestination.
     */
    protected class LocationData{
        // key: material ID, value: MaterialAtDestination
        public Map<Integer,MaterialAtDestination> materialAtLocation = new HashMap<>();
        public double latitude;
        public double longitude;
    }

    /**
     * The MaterialAtDestination-object contains fields corresponding to information about a particular material type
     * at the location (destination) in question. Each material type at a location (destination) is assigned a
     * destination ID.
     */
    protected class MaterialAtDestination{
        public double weight;
        public int destinationID;
    }
}
