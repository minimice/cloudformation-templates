package com.scania.lotsdatahandling.domain;


// TODO make the class serializable


public class GeographicPose {
    private double latitude;
    private double longitude;
    private double altitude;
    private double heading;

    public double getHeading() {
        return heading;
    }

    public void setHeading(double heading) {
        this.heading = heading;
    }

    public GeographicPose() {
        this.latitude = 0;
        this.longitude = 0;
        this.altitude = 0;
        this.heading = 0;
    }

    public GeographicPose(double longitude, double latitude, double heading) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.heading = heading;
        this.altitude = 0;
    }

    public GeographicPose(double longitude, double latitude, double heading, double alt) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.altitude = alt;
        this.heading = heading;
    }


    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public void setAltitude(double altitude) {
        this.altitude = altitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public double getAltitude() {
        return altitude;
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof GeographicPose)) {
            return false;
        }

        GeographicPose geographicPose = (GeographicPose) other;

        boolean latitudesAreEqual = this.latitude == geographicPose.getLatitude();
        boolean longitudesAreEqual = this.longitude == geographicPose.getLongitude();
        boolean altitudesAreEqual = this.altitude == geographicPose.getAltitude();
        // Note that heading is excluded from equal method!

        return latitudesAreEqual && longitudesAreEqual && altitudesAreEqual;

    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 61 * hash + (int) (Double.doubleToLongBits(this.latitude) ^ (Double.doubleToLongBits(this.latitude) >>> 32));
        hash = 61 * hash + (int) (Double.doubleToLongBits(this.longitude) ^ (Double.doubleToLongBits(this.longitude) >>> 32));
        hash = 61 * hash + (int) (Double.doubleToLongBits(this.altitude) ^ (Double.doubleToLongBits(this.altitude) >>> 32));
        // Node that heading is excluded from hash value!
        return hash;
    }

}
