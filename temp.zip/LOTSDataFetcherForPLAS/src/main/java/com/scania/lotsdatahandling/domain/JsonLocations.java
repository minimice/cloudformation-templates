package com.scania.lotsdatahandling.domain;


import java.util.List;

public class JsonLocations{

    private List<Location> locations;

    public JsonLocations() {
    }

    public void setLocations(List<Location> locations) {
        this.locations = locations;
    }

    public List<Location> getLocations() {
        return locations;
    }

}
