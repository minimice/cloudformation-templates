package com.scania.lotsdatahandling.dataBasedPlannerHelpClasses;

//import com.microsoft.windowsazure.core.utils.BOMInputStream;
import com.microsoft.windowsazure.core.utils.BOMInputStream;
import com.scania.lotsdatahandling.LotsDomain.LotsDeliveryPlan;
import com.scania.lotsdatahandling.LotsDomain.LotsLocationStock;
import com.scania.lotsdatahandling.LotsDomain.LotsReceiver;
import com.scania.lotsdatahandling.domain.Material;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * The DataListsForPlanner-object contains fields with information equivalent to that in the corresponding
 * csv-files, see test/resources/dataForPlannerTests, and methods for setting and getting those fields.
 * <p>
 * Note that the information is not modified in any way, it is simply translated from csv-files to ArrayLists.
 *
 * @author MANRRZ
 */
public class DataListsForPlanner {

    private ArrayList<DestinationInfoData> destinationInfoDataList;
    private ArrayList<DestinationDemandData> destinationDemandDataList;
    private ArrayList<SourceInfoAndSupplyData> sourceInfoAndSupplyDataList;
    private ArrayList<VehicleInfo> vehicleInfoList;
    private ArrayList<MaterialInfo> materialInfoList;

    public DataListsForPlanner() {
        this.destinationInfoDataList = new ArrayList<>();
        this.destinationDemandDataList = new ArrayList<>();
        this.sourceInfoAndSupplyDataList = new ArrayList<>();
        this.materialInfoList = new ArrayList<>();
    }
    

    public void setDataListsForPlannerFromAPI(LotsTranslationManager manager, String sourceDate, String destinationFromDate, String destinationToDate){
        this.destinationInfoDataList = readAndGetDestinationInfoDataList(manager);
        this.destinationDemandDataList = readAndGetDestinationDemandDataList(manager, destinationFromDate, destinationToDate);
        this.sourceInfoAndSupplyDataList = readAndGetSourceInfoAndSupplyDataList(manager, sourceDate, sourceDate);
        this.vehicleInfoList = readAndGetVehicleInfoList();
        this.materialInfoList = readAndGetMaterialInfoList(manager, sourceDate, sourceDate);
    }

    /**
     * Gets the field destinationInfoDataList which contains the information read from the csv-file
     * test/resources/dataForPlannerTests/"catalogWithDataToUse"/destinationInfo.csv
     *
     * @return ArrayList<DestinationInfoData>
     */
    public ArrayList<DestinationInfoData> getDestinationInfoDataList(){
        return this.destinationInfoDataList;
    }

    /**
     * Gets the field destinationDemandDataList which contains the information read from the csv-file
     * test/resources/dataForPlannerTests/"catalogWithDataToUse"/destinationDemand.csv
     *
     * @return ArrayList<DestinationInfoData>
     */
    public ArrayList<DestinationDemandData> getDestinationDemandDataList(){
        return this.destinationDemandDataList;
    }

    /**
     * Gets the field sourceInfoAndSupplyDataList which contains the information read from the csv-file
     * test/resources/dataForPlannerTests/"catalogWithDataToUse"/sourceInfoAndSupply.csv
     *
     * @return ArrayList<DestinationInfoData>
     */
    public ArrayList<SourceInfoAndSupplyData> getSourceInfoAndSupplyDataList(){
        return this.sourceInfoAndSupplyDataList;
    }

    /**
     * Returns the list of vehicles read from the csv file vehicleList.csv
     *
     * @returns Vehicle information list
     */
    public ArrayList<VehicleInfo> getVehicleInfoList() {
        return this.vehicleInfoList;
    }

    /**
     * Returns the list of materials
     *
     * @returns Material information list
     */
    public ArrayList<MaterialInfo> getMaterialInfoList() {
        return this.materialInfoList;
    }

    /**
     * Reads vehicle info from the csv file
     */
    private ArrayList<VehicleInfo> readAndGetVehicleInfoList() {
        ArrayList<VehicleInfo>  vehicleInfoList = new ArrayList<>();
        InputStream stream = this.getClass().getResourceAsStream("/vehicleList.csv");
        try {
            Reader reader = new InputStreamReader(new BOMInputStream(stream), "UTF-8");
            CSVParser records = new CSVParser(reader, CSVFormat.TDF.withDelimiter(';').withFirstRecordAsHeader());

            for (CSVRecord vehicleEntry : records) {
                VehicleInfo vehicleInfo = new VehicleInfo();
                vehicleInfo.vehicleId   = vehicleEntry.get("vehicleId");
                vehicleInfo.capacity    = vehicleEntry.get("capacity(m3)");
                vehicleInfoList.add(vehicleInfo);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return vehicleInfoList;
    }

    private ArrayList<DestinationInfoData> readAndGetDestinationInfoDataList(LotsTranslationManager manager) {

        ArrayList<DestinationInfoData> destinationInfoDataList = new ArrayList<>();

        List<LotsReceiver> receivers = manager.fetchReceiver();
        if (null == receivers) {
            System.out.println("There is no destination!");
        } else {
            for (LotsReceiver destinationInfoEntry : receivers) {
                DestinationInfoData destinationInfoData = new DestinationInfoData();
                destinationInfoData.latitude = "" + destinationInfoEntry.ReceiverLat;
                destinationInfoData.longitude = "" + destinationInfoEntry.ReceiverLong;
                destinationInfoData.locationID = "" + destinationInfoEntry.ReceiverNumber.trim();
                if(destinationInfoData.locationID.isEmpty()){continue;};
                destinationInfoDataList.add(destinationInfoData);
            }
        }

        return destinationInfoDataList;
    }

    private ArrayList<DestinationDemandData> readAndGetDestinationDemandDataList(LotsTranslationManager manager, String fromDate, String toDate) {
        ArrayList<DestinationDemandData> destinationDemandDataList = new ArrayList<>();

        List<LotsDeliveryPlan> deliveryPlans = manager.fetchDeliveriPlan(fromDate,toDate);
        if (null == deliveryPlans) {
            System.out.println("There is no delivery plan!");
        } else {
            for (LotsDeliveryPlan destinationDemandEntry : deliveryPlans) {
                DestinationDemandData destinationDemandData = new DestinationDemandData();
                destinationDemandData.materialID = destinationDemandEntry.ProductNumber.trim();
                if(destinationDemandData.materialID.isEmpty()){continue;};
                destinationDemandData.volume = "" + destinationDemandEntry.Volume;
                if(destinationDemandData.volume.isEmpty()){continue;};
                destinationDemandData.locationID = destinationDemandEntry.ReceiverNumber.trim();
                if(destinationDemandData.locationID.isEmpty()){continue;};
                destinationDemandDataList.add(destinationDemandData);
            }
        }
        return destinationDemandDataList;
            }

    private ArrayList<SourceInfoAndSupplyData> readAndGetSourceInfoAndSupplyDataList(LotsTranslationManager manager, String fromDate, String toDate) {
        List<LotsLocationStock> locationStocks = manager.fetchLocationStock(fromDate, toDate);

        if (null == locationStocks) {
            System.out.println("There is no source!");
        } else {
            for (LotsLocationStock sourceInfoAndSupplyEntry : locationStocks) {
                SourceInfoAndSupplyData sourceInfoAndSupplyData = new SourceInfoAndSupplyData();
                sourceInfoAndSupplyData.latitude = "" + sourceInfoAndSupplyEntry.LocationLat;
                sourceInfoAndSupplyData.longitude = "" + sourceInfoAndSupplyEntry.LocationLong;
                sourceInfoAndSupplyData.locationID = sourceInfoAndSupplyEntry.LocationNumber.trim();
                if(sourceInfoAndSupplyData.locationID.isEmpty()){continue;};
                sourceInfoAndSupplyData.materialID = sourceInfoAndSupplyEntry.ProductNumber.trim();
                if(sourceInfoAndSupplyData.materialID.isEmpty()){continue;};
                sourceInfoAndSupplyData.volume = "" + sourceInfoAndSupplyEntry.Stocklevel;
                sourceInfoAndSupplyData.designatedDestinationLocationID = sourceInfoAndSupplyEntry.ReceiverNumber.trim();
                if(sourceInfoAndSupplyData.designatedDestinationLocationID.isEmpty()){continue;};
                sourceInfoAndSupplyData.priorityNumber = "1";
                sourceInfoAndSupplyDataList.add(sourceInfoAndSupplyData);
            }
        }

        return sourceInfoAndSupplyDataList;
    }

    private ArrayList<MaterialInfo> readAndGetMaterialInfoList(LotsTranslationManager manager, String fromDate, String toDate) {
        List<LotsLocationStock> locationStocks = manager.fetchLocationStock(fromDate, toDate);
        ArrayList<String> materialIdList = new ArrayList<>();
        if (null == locationStocks) {
            System.out.println("There is no source!");
        } else {
            for (LotsLocationStock materialInfoEntry : locationStocks) {
                MaterialInfo materialInfo = new MaterialInfo();
                materialInfo.materialId = materialInfoEntry.ProductNumber.trim();
                materialInfo.materialName = materialInfoEntry.ProductName;
                if (materialIdList.isEmpty()){
                    materialInfoList.add(materialInfo);
                } else if (!materialIdList.contains(materialInfo)){
                    materialInfoList.add(materialInfo);
                }
            }
        }

        ArrayList<DestinationDemandData> destinationDemandDataList = new ArrayList<>();

        List<LotsDeliveryPlan> deliveryPlans = manager.fetchDeliveriPlan(fromDate,toDate);
        if (null == deliveryPlans) {
            System.out.println("There is no delivery plan!");
        } else {
            for (LotsDeliveryPlan materialInfoEntry : deliveryPlans) {
                MaterialInfo materialInfo = new MaterialInfo();
                materialInfo.materialId = materialInfoEntry.ProductNumber.trim();
                materialInfo.materialName = materialInfoEntry.ProductName;
                if (materialIdList.isEmpty()){
                    materialInfoList.add(materialInfo);
                } else if (!materialIdList.contains(materialInfo)){
                    materialInfoList.add(materialInfo);
                }
            }
        }

        return materialInfoList;
    }

    private ArrayList<VehicleInfo> readAndGetVehicleInfoList(LotsTranslationManager manager) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    /**
     * The DestinationInfoData-object contains fields corresponding to the information in
     * test/resources/dataForPlannerTests/"catalogWithDataToUse"/destinationInfo.csv.
     */
    protected class DestinationInfoData {

        public String latitude;
        public String longitude;
        public String locationID;
    }

    /**
     * The DestinationDemandData-object contains fields corresponding to the information in
     * test/resources/dataForPlannerTests/"catalogWithDataToUse"/destinationDemand.csv.
     */
    protected class DestinationDemandData {

        public String materialID;
        public String volume;
        public String locationID;
    }

    /**
     * The SourceInfoAndSupplyData-object contains fields corresponding to the information in
     * test/resources/dataForPlannerTests/"catalogWithDataToUse"/sourceInfoAndSupply.csv.
     */
    protected class SourceInfoAndSupplyData {

        public String latitude;
        public String longitude;
        public String locationID;
        public String materialID;
        public String volume;
        public String designatedDestinationLocationID;
        public String priorityNumber;
    }

    /**
     * The VehicleInfo object contains fields corresponding to vehicle ID and vehicle capacity (m3)
     */
    protected class VehicleInfo {
        public String vehicleId;
        public String capacity;
    }

    /**
     * The MaterialInfo object contains fields corresponding to vehicle ID and vehicle capacity (m3)
     */
    public class MaterialInfo {
        public String materialId;
        public String materialName;

        @Override
        public int hashCode() {
            int hash = 7;
            hash = 17 * hash + Objects.hashCode(this.materialId);
            return hash;
        }

        @Override
        public boolean equals(Object obj){
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final MaterialInfo other = (MaterialInfo) obj;
            if (Long.parseLong(this.materialId)==Long.parseLong(other.materialId)) {
                return true;
            }
            return false;
        }
    }
}
