/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.scania.lotsdatahandling;

import com.google.gson.Gson;
import com.scania.lotsdatahandling.dataBasedPlannerHelpClasses.*;
import com.scania.lotsdatahandling.domain.*;
import java.io.FileOutputStream;

import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author JAKFVY
 */
public class LOTSDataHandling {

    public static void main(String[] args) throws IOException {
        
        if(args.length != 3) {
            System.err.println("Usage: <source date> <dest from date> <dest to date>, "
                    + "example: 20171102 20171106 20171110");
            return;
        }
        System.out.println("Fetching data from lots API...");
        DataListsForPlanner dataListsForPlanner = new DataListsForPlanner();
        dataListsForPlanner.setDataListsForPlannerFromAPI(new LotsTranslationManager(), args[0], args[1], args[2]);

        SourceMapForPlanner sourceMapForPlanner = new SourceMapForPlanner();
        sourceMapForPlanner.setSourceMap(dataListsForPlanner);
        SourceListForPlanner sourceListForPlanner = new SourceListForPlanner();
        sourceListForPlanner.setSourceListForAPI(sourceMapForPlanner.getSourceMap());
        List<Storage> sourcesAPI = sourceListForPlanner.getSourceListAPI();
        System.out.println("Sources list built! Number of sources: " + sourcesAPI.size());
        if (0 == sourcesAPI.size()) {
            System.out.println("There is no source! Aborting!");
            return;
        }

        DestinationMapForPlanner destinationMapForPlanner = new DestinationMapForPlanner();
        destinationMapForPlanner.setDestinationMap(dataListsForPlanner);

        DestinationListForPlanner destinationListForPlanner = new DestinationListForPlanner();
        destinationListForPlanner.setDestinationListAPI(destinationMapForPlanner.getDestinationMap());
        List<Storage> destinationsAPI = destinationListForPlanner.getDestinationListAPI();
        System.out.println("Destinations list built! Number of destinations: " + destinationsAPI.size());
        if (0 == destinationsAPI.size()) {
            System.out.println("There is no destination! Aborting!");
            return;
        }
        
        VehicleListForPlannerAPI vehicleListForPlanner = new VehicleListForPlannerAPI(dataListsForPlanner);
        List<Vehicle> vehicleList = vehicleListForPlanner.getVehicleList();
        System.out.println("Vehicles list built! (Fetched from local resource) Number of vehicles: " + vehicleList.size());
        if (0 == vehicleList.size()) {
            System.out.println("There is no vehicle! Aborting!");
            return;
        }

        MaterialListForPlanner materialListForPlanner = new MaterialListForPlanner(dataListsForPlanner);
        List<Material> materialTypeList = materialListForPlanner.getMaterialTypeList();
        System.out.println("Materials list built! Number of materials: " + materialTypeList.size());
        if (0 == materialTypeList.size()) {
            System.out.println("There is no material! Aborting!");
            return;
        }

        JsonStorages sources = new JsonStorages();
        JsonStorages destinations = new JsonStorages();

        sources.setStorages(sourcesAPI);
        destinations.setStorages(destinationsAPI);

        JsonRequestVehicles requestVehicles = new JsonRequestVehicles();
        requestVehicles.setVehicles(vehicleList);

        JsonRequestMaterialTypes requestMaterialTypes = new JsonRequestMaterialTypes();
        requestMaterialTypes.setMaterialTypes(materialTypeList);

        Gson gson = new Gson();

        List<String> files = new ArrayList<String>();

        for (String name : Arrays.asList("sourceList", "destinationList", "vehicleList", "materialTypeList")) {
            files.add(args[0]+"_"+args[1]+"_"+args[2]+"_"+name+".json");
        }

        Writer writer;
        writer = new FileWriter(files.get(0));
        gson.toJson(sources, writer);
        writer.close();
        writer = new FileWriter(files.get(1));
        gson.toJson(destinations, writer);
        writer.close();
        writer = new FileWriter(files.get(2));
        gson.toJson(requestVehicles, writer);
        writer.close();
        writer = new OutputStreamWriter(new FileOutputStream(files.get(3)), StandardCharsets.UTF_8);
        gson.toJson(requestMaterialTypes, writer);
        writer.close();
        
        System.out.println("Files created:");
        for (String file : files) {
            System.out.println("    " + file);
        }
    }
}

