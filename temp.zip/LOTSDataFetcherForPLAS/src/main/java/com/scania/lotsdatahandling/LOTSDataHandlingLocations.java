/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.scania.lotsdatahandling;

import com.google.gson.Gson;
import com.scania.lotsdatahandling.LotsDomain.LotsLocation;
import com.scania.lotsdatahandling.LotsDomain.LotsReceiver;
import com.scania.lotsdatahandling.dataBasedPlannerHelpClasses.DataListsForPlanner;
import com.scania.lotsdatahandling.dataBasedPlannerHelpClasses.DestinationListForPlanner;
import com.scania.lotsdatahandling.dataBasedPlannerHelpClasses.DestinationMapForPlanner;
import com.scania.lotsdatahandling.dataBasedPlannerHelpClasses.LotsTranslationManager;
import com.scania.lotsdatahandling.dataBasedPlannerHelpClasses.SourceListForPlanner;
import com.scania.lotsdatahandling.dataBasedPlannerHelpClasses.SourceMapForPlanner;
import com.scania.lotsdatahandling.dataBasedPlannerHelpClasses.VehicleListForPlannerAPI;
import com.scania.lotsdatahandling.domain.GeographicPose;
import com.scania.lotsdatahandling.domain.JsonLocations;
import com.scania.lotsdatahandling.domain.JsonRequestVehicles;
import com.scania.lotsdatahandling.domain.JsonStorages;
import com.scania.lotsdatahandling.domain.Location;
import com.scania.lotsdatahandling.domain.Storage;
import com.scania.lotsdatahandling.domain.Vehicle;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

/**
 *
 * @author JAKFVY
 */
public class LOTSDataHandlingLocations {

    public static void main(String[] args) throws IOException {
        
        //if(args.length != 0) {
          //  System.err.println("Please run without arguments!");
            //return;
       // }
        
        
        LotsTranslationManager manager = new LotsTranslationManager();

        List<LotsLocation> locationsFromLOTS = manager.fetchLocation(args[0], args[1]);
        List<LotsReceiver> receiversFromLOTS = manager.fetchReceiver();
        
                List<Location> locations = new ArrayList<>();
                List<Long> locationsID = new ArrayList<>();
        for (LotsLocation location : locationsFromLOTS) {
            try {
                Location newLocation = new Location();
                if(location.LocationNumber.trim().isEmpty()){continue;};
                newLocation.setId(new Long(location.LocationNumber.trim()));
                newLocation.setName(location.LocationName);
                newLocation.setPoint(new GeographicPose(location.LocationLong, location.LocationLat, 0));
                if (locationsID.contains(new Long(location.LocationNumber.trim()))){
                    continue;
                }
                locations.add(newLocation);
                locationsID.add(new Long(location.LocationNumber.trim()));
            } catch (NumberFormatException ex) {

            }
        }

        for (LotsReceiver receiver : receiversFromLOTS) {
            try {
                Location newLocation = new Location();
                newLocation.setId(new Long(receiver.ReceiverNumber));
                newLocation.setName(receiver.ReceiverName);
                newLocation.setPoint(new GeographicPose(receiver.ReceiverLong, receiver.ReceiverLat, 0));
                locations.add(newLocation);
            } catch (NumberFormatException ex) {

            }
        }

        JsonLocations jsonLocations = new JsonLocations();
        
        jsonLocations.setLocations(locations);

        System.out.println("Locations list build, number of locations: " + locations.size());

        Gson gson = new Gson();

        String file = "locationList.json";
        Writer writer;
        writer = new FileWriter(file);
        gson.toJson(jsonLocations, writer);
        writer.close();

        System.out.println("File created: " + file);
    }
}
