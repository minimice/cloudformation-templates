package com.scania.lotsdatahandling;

import com.google.gson.Gson;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

/**
 *
 * @author JAKFVY
 */
public class RequestUtil {
    
    public static Response sendPutRequest(WebTarget target, Object jsonObject, Gson gson) throws Exception {
        String json = gson.toJson(jsonObject);
        
//        System.out.println("json: " + json);
        System.out.println("Will send request to: " + target.getUri().toURL());
        Response response = target.request().header("Content-Type", "application/json; charset=utf-8")
                .put(Entity.json(json));
        if (response.getStatus() != 200) {
            throw new Exception("Got status code " + response.getStatus() + " when trying to request " + target.getUri().toURL());
        }
        return response;
    }
}
