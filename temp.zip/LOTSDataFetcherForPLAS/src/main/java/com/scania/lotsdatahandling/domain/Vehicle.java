package com.scania.lotsdatahandling.domain;

import com.scania.lotsdatahandling.geo.GeographicPose;
import java.util.List;
import java.util.Objects;

public class Vehicle {
    @JsonRequired
    private final Long id;
    @JsonRequired
    private final List<VehicleLoad> vehicleLoad;
    @JsonRequired
    private GeographicPose location = new GeographicPose();
    @JsonRequired
    private Double speed;

    public Vehicle(Long id, List<VehicleLoad> vehicleLoad) {
        this.id = id;
        this.vehicleLoad = vehicleLoad;
    }

    public Long getId() {
        return id;
    }

    public GeographicPose getLocation() {
        return location;
    } 

    public List<VehicleLoad> getVehicleLoad() {
        return this.vehicleLoad;
    }

    public void setSpeed(Double speed) {
        this.speed = speed;
    }

    public Double getSpeed() {
        return speed;
    }    

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Vehicle other = (Vehicle) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

}
