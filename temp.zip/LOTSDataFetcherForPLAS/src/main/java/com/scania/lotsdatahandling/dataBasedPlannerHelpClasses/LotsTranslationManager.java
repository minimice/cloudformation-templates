package com.scania.lotsdatahandling.dataBasedPlannerHelpClasses;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.scania.lotsdatahandling.LotsDomain.LotsDeliveryPlan;
import com.scania.lotsdatahandling.LotsDomain.LotsLocation;
import com.scania.lotsdatahandling.LotsDomain.LotsLocationStock;
import com.scania.lotsdatahandling.LotsDomain.LotsReceiver;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


public class LotsTranslationManager {

    public String fetch(String api, Map<String, String> queryParams) {
        javax.ws.rs.client.Client client = ClientBuilder.newClient();

        WebTarget target = client.target("https://lotsexternalapi.azurewebsites.net/api/");
        target = target.path(api);
        for (Map.Entry<String, String> en : queryParams.entrySet()) {
            String key = en.getKey();
            String value = en.getValue();
            target = target.queryParam(key, value);
        }

        Response response = target.request()
                .header("Authorization", "TVzJYjvygCxfPKMKujAMrb95")
                .get();
        return response.readEntity(String.class);
    }

    public String fetch(String api) {
        return fetch(api, new HashMap<>());
    }

    public String curl(String plasBase, String endpoint, String data) {
        String string = "curl -D'" + data + "' " + plasBase + "/v1.0/" + endpoint;
        return string;
    }

    public List<LotsDeliveryPlan> fetchDeliveriPlan(String fromDate, String toDate) {
        Map<String, String> params = new HashMap<>();
        params.put("fromdate", fromDate);
        params.put("todate", toDate);
        return new Gson().fromJson(fetch("DeliveryPlan", params), new TypeToken<List<LotsDeliveryPlan>>() {
        }.getType());
    }

    public List<LotsLocation> fetchLocation(String fromDate, String toDate) {
        Map<String, String> params = new HashMap<>();
        params.put("fromdate", fromDate);
        params.put("todate", toDate);
        return new Gson().fromJson(fetch("LocationStock", params), new TypeToken<List<LotsLocation>>() {
        }.getType());
    }

    public List<LotsLocationStock> fetchLocationStock(String fromDate, String toDate) {
        Map<String, String> params = new HashMap<>();
        params.put("fromdate", fromDate);
        params.put("todate", toDate);
        return new Gson().fromJson(fetch("LocationStock", params), new TypeToken<List<LotsLocationStock>>() {
        }.getType());
    }

    public List<LotsReceiver> fetchReceiver() {
        return new Gson().fromJson(fetch("Receiver"), new TypeToken<List<LotsReceiver>>() {
        }.getType());
    }
}
