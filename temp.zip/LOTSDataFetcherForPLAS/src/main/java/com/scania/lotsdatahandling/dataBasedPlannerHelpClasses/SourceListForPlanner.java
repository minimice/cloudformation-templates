package com.scania.lotsdatahandling.dataBasedPlannerHelpClasses;

import com.scania.lotsdatahandling.proto.LoadTypeMiningOuterClass;
import com.scania.lotsdatahandling.geo.GeographicPose;
import com.scania.lotsdatahandling.domain.Storage;
import com.scania.lotsdatahandling.domain.StorageType;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The SourceListForPlanner-object has a field containing a list of sources, that is
 * List<SourceOuterClass.Source> sourceList.
 * This list is what is used to set up a planning-problem for the planner to solve.
 *
 * @author MANRRZ
 */
public class SourceListForPlanner {
    
    private List<Storage> sourceListAPI;


    public void setSourceListForAPI(Map<Integer,SourceMapForPlanner.LocationData> sourceMap) {
        this.sourceListAPI = calculateAndGetSourceListForPlannerForApi(sourceMap);
    }

    public List<Storage> getSourceListAPI() {
        return sourceListAPI;
    }
    


    private List<Storage> calculateAndGetSourceListForPlannerForApi(Map<Integer, SourceMapForPlanner.LocationData> sourceMap) {
        List<Storage> sourceList = new ArrayList<>();
        for (int sourceMapKey : sourceMap.keySet()){// for every location (source)
            SourceMapForPlanner.LocationData locationData = sourceMap.get(sourceMapKey);
            for (int materialAtLocationKey : locationData.materialAtLocation.keySet()){// for every designated destination location
                Map<Integer, SourceMapForPlanner.MaterialAtSource> materialAtLocationValue = locationData.materialAtLocation.get(materialAtLocationKey);
                for (int materialAtLocationValueKey : materialAtLocationValue.keySet()){// for every material type
                    SourceMapForPlanner.MaterialAtSource materialAtSource = materialAtLocationValue.get(materialAtLocationValueKey);
                    long id = materialAtSource.sourceID;
                    double altitude = 0D;
                    double longitude = locationData.longitude;
                    double latitude = locationData.latitude;
                    if (0.0d == longitude && 0.0d == latitude) {
                        System.out.println("Source " + Long.toString(id) + " is excluded, since it has invalid coordinates (both longitude and latitude are 0.0)!");
                    } else {
                        double inFlow = materialAtSource.weight;
                        LoadTypeMiningOuterClass.LoadTypeMining typeOfMaterial = LoadTypeMiningOuterClass.LoadTypeMining.LOAD_TYPE_OTHER;
                        long locationId = sourceMapKey;
                        long designatedDestinationLocationId = materialAtLocationKey;
                        long loadTime = 30 * 60 * 1000; // 30 minutes in milliseconds
                        long priority = 1;
                        long materialId = materialAtLocationValueKey;
                        GeographicPose pose = new GeographicPose(longitude, latitude, altitude);
                        Storage storage = new Storage(StorageType.DESTINATION, id, typeOfMaterial, pose, pose, inFlow, materialId, priority, loadTime, designatedDestinationLocationId, locationId);
                        sourceList.add(storage);
                    }
                }
            }
        }
        return sourceList;
    }

}
