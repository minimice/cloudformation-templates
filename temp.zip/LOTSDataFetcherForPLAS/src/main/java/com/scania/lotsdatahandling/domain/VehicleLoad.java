package com.scania.lotsdatahandling.domain;



public class VehicleLoad {
    private final LoadType loadType;
    private final Double maxLoad;

    public VehicleLoad(LoadType loadType, Double maxLoad) {
        this.loadType = loadType;
        this.maxLoad = maxLoad;
    }

    public LoadType getLoadType() {
        return loadType;
    }

    public Double getMaxLoad() {
        return maxLoad;
    }
    
    
    
}
