package com.scania.lotsdatahandling.dataBasedPlannerHelpClasses;

import java.util.HashMap;
import java.util.Map;

/**
 * The SourceMapForPlanner-object has a field containing a HashMap with (maybe) modified information from
 * the DataListsForPlanner dataListsForPlanner, that is
 * Map<Integer,LocationData> sourceMap.
 * The key is the location ID of the source, and the value is the corresponding location data.
 * <p>
 * The information is modified if equivalent multiples of sources are present in dataListsForPlanner.
 *
 * @author MANRRZ
 */
public class SourceMapForPlanner {

    private Map<Integer,SourceMapForPlanner.LocationData> sourceMap;

    public SourceMapForPlanner(){
        this.sourceMap = new HashMap<>();
    }

    /**
     * Gets the field sourceMap, that is
     * Map<Integer,LocationData> sourceMap.
     * The key is the location ID of the source, and the value is the corresponding location data.
     *
     * @return Map<Integer,LocationData> sourceMap
     */
    public Map<Integer,LocationData> getSourceMap() {
        return this.sourceMap;
    }

    /**
     * Sets the field sourceMap according to the DataListsForPlanner dataListsForPlanner.
     *
     * @param dataListsForPlanner
     */
    public void setSourceMap(DataListsForPlanner dataListsForPlanner) {
        this.sourceMap = calculateAndGetSourceMap(dataListsForPlanner);
    }

    /**
     * Reads the information of the DataListsForPlanner dataListsForPlanner and (maybe) modifies it and creates the
     * HashMap sourceMap.
     *
     * @param dataListsForPlanner
     * @return Map<Integer, LocationData>
     */
    private Map<Integer, LocationData> calculateAndGetSourceMap(DataListsForPlanner dataListsForPlanner) {
        Map<Integer, LocationData> sourceMap = new HashMap<>();

        int sourceID = 0;
        for (DataListsForPlanner.SourceInfoAndSupplyData sourceEntry : dataListsForPlanner.getSourceInfoAndSupplyDataList()) {
            LocationData locationData = new LocationData();
            locationData.latitude = Double.parseDouble(sourceEntry.latitude);
            locationData.longitude = Double.parseDouble(sourceEntry.longitude);
            if (null == sourceEntry.priorityNumber){locationData.priorityNumber = 10;}else{locationData.priorityNumber = Double.parseDouble(sourceEntry.priorityNumber);};
            int locationID = Integer.parseInt(sourceEntry.locationID);
            int materialID = Integer.parseInt(sourceEntry.materialID);
            double weight = 1 * Double.parseDouble(sourceEntry.volume); // transformation coefficient m3 -> ton is set to 1
            int designatedDestinationLocationID = Integer.parseInt(sourceEntry.designatedDestinationLocationID);
            // Check if this is the first encounter with source denoted by locationNumber
            if (sourceMap.containsKey(locationID)) {
                locationData = sourceMap.get(locationID);
                if (locationData.materialAtLocation != null) {
                    // Check if this is the first encounter with source denoted by locationID and designated destination denoted by designatedDestinationLocationID
                    if (locationData.materialAtLocation.containsKey(designatedDestinationLocationID)) {
                        Map<Integer, MaterialAtSource> materialAtSourceMap = locationData.materialAtLocation.get(designatedDestinationLocationID);
                        // Check if this is the first encounter with source denoted by locationNumber and designated destination denoted by designatedDestinationLocationID and material type denoted by materialID
                        if (materialAtSourceMap.containsKey(materialID)) {
                            MaterialAtSource materialAtSource = materialAtSourceMap.get(materialID);
                            materialAtSource.weight += weight;
                            materialAtSourceMap.put(materialID, materialAtSource);
                            locationData.materialAtLocation.put(designatedDestinationLocationID,materialAtSourceMap);
                        } else {
                            MaterialAtSource materialAtSource = new MaterialAtSource();
                            materialAtSource.weight = weight;
                            materialAtSource.sourceID = sourceID;
                            materialAtSourceMap.put(materialID, materialAtSource);
                            locationData.materialAtLocation.put(designatedDestinationLocationID,materialAtSourceMap);
                            sourceID++;
                        }
                    } else {
                        MaterialAtSource materialAtSource = new MaterialAtSource();
                        materialAtSource.weight = weight;
                        materialAtSource.sourceID = sourceID;
                        Map<Integer, MaterialAtSource> materialAtSourceMap = new HashMap<>();
                        materialAtSourceMap.put(materialID, materialAtSource);
                        locationData.materialAtLocation.put(designatedDestinationLocationID, materialAtSourceMap);
                        sourceID++;
                    }
                } else {
                    MaterialAtSource materialAtSource = new MaterialAtSource();
                    materialAtSource.weight = weight;
                    materialAtSource.sourceID = sourceID;
                    Map<Integer, MaterialAtSource> materialAtSourceMap = new HashMap<>();
                    materialAtSourceMap.put(materialID, materialAtSource);
                    locationData.materialAtLocation.put(designatedDestinationLocationID, materialAtSourceMap);
                    sourceID++;
                }
            } else {
                MaterialAtSource materialAtSource = new MaterialAtSource();
                materialAtSource.weight = weight;
                materialAtSource.sourceID = sourceID;
                Map<Integer, MaterialAtSource> materialAtSourceMap = new HashMap<>();
                materialAtSourceMap.put(materialID, materialAtSource);
                Map<Integer, Map<Integer, MaterialAtSource>> materialAtLocation = new HashMap<>();
                materialAtLocation.put(designatedDestinationLocationID, materialAtSourceMap);
                locationData.materialAtLocation = materialAtLocation;
                sourceID++;
            }
            sourceMap.put(Integer.parseInt(sourceEntry.locationID), locationData);
        }
        return sourceMap;
    }

    /**
     * The LocationData-object contains fields corresponding to information about the location (source)
     * in question.
     * <p>
     * The field Map<Integer,MaterialAtSource> materialAtLocation has as key the material ID and as value a second
     * HashMap. The second HasMap has as key the material ID and as value MaterialAtSource.
     */
    protected class LocationData{
        // key: designated destination location ID, value: new map, new map key: material ID, new map value: MaterialAtSource
        public Map<Integer, Map<Integer, MaterialAtSource>> materialAtLocation = new HashMap<>();
        public double latitude;
        public double longitude;
        public double priorityNumber;
    }

    /**
     * The MaterialAtSource-object contains fields corresponding to information about a particular material type
     * at the location (source) in question. Each material type at a location (source) is assigned a
     * source ID.
     */
    protected class MaterialAtSource{
        public double weight;
        public int sourceID;
    }
}
