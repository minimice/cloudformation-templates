package com.scania.lotsdatahandling.domain;

import java.util.List;


public class JsonRequestVehicles {
    @JsonRequired
    private List<Vehicle> vehicles;

    public List<Vehicle> getVehicles() {
        return vehicles;
    }

    public void setVehicles(List<Vehicle> vehicles) {
        this.vehicles = vehicles;
    }
    
}
