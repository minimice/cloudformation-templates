# LOTSDataFetcherForPLAS

### Usage

- Build with ```mvn package``` 
- From bash shell, run


```./lots.sh <source date> <dest from date> <dest to date> <planner uri>```
- example


```./lots.sh 20171102 20171106 20171110 https://ice-lots.eci.zone/planner```

- Please note that `lots.sh` will try to extract your proxy username and password from the `http_proxy` environment variable in order to pass it by to java. Ensure it is set and up to date!

